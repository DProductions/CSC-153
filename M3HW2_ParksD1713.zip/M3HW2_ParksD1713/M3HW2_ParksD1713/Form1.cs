﻿/**
* Date : 05 Mar 2023
* CSC 153
* Daniel Parks
* Random Number Guessing Game
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace M3HW2_ParksD1713
{
    public partial class frmRandomNumber : Form
    {
        public frmRandomNumber()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGuess_Click(object sender, EventArgs e)
        {
            int guess = int.Parse(txbUserGuess.Text);

            int number;
            Random rand = new Random();
            number = rand.Next(1, 101);
            int count = 0;

            while (true)
            {
                if (number > guess)
                {

                    lblGuess.Text = ("Too low, try again"+count).ToString();

                    return;
                }
                if(number< guess)
                {

                    lblGuess.Text = ("Too high, try again"+count).ToString();

                    return;
                }

            }

            lblGuess.Text = ("Congrats! You guessed the number!" +number).ToString();






        }
    }
}
