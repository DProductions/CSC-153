﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace WindowsFormsApp1
{
    public partial class frmFallingDistance : Form
    {
        public frmFallingDistance()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double timeInput = double.Parse(tbxSeconds.Text);
            double distance;
            if (timeInput <= 0)
            {
                MessageBox.Show("Please enter a valid amount of time in seconds.");
            }
            else if (timeInput >0)
            {

                distance = CalculationsBase.FallingDistance(timeInput);

                MessageBox.Show("The total distance traveled is\n" + distance + " meters.");
            }
            else
            {
                MessageBox.Show("Please enter a valid amount of time in seconds.");
            }
        }


    }
}
