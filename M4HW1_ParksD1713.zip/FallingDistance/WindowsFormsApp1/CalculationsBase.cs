﻿namespace WindowsFormsApp1
{
    public class CalculationsBase
    {
        public static double FallingDistance(double time)
        {
            double distance = 0.5 * 9.8 * (time * time);

            return distance;
        }
    }
}