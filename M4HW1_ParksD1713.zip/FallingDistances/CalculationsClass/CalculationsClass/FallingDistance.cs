﻿/**
* 20 March 2023
* CSC 153
* Daniel Parks
* Program description - Calculate Falling distance. Resubmitted after clerification in class.
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculationsClass
{
    public class FallingDistance
    {
        public static double FallingDistanceCalc(double time)
        {
            double distance = 0.5 * 9.8 * (time * time);

            return distance;
        }
    }
}
