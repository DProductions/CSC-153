﻿/**
* 20 March 2023
* CSC 153
* Daniel Parks
* Program description - Calculate Falling distance. Resubmitted after clerification in class.
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CalculationsClass;





namespace FallingForm1
{
    public partial class FallingForm1 : Form
    {
        public FallingForm1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double timeInput = double.Parse(tbxSeconds.Text);
            double distance;

            if (timeInput <= 0)
            {
                MessageBox.Show("Please enter a valid amount of time in seconds.");
            }
            else if (timeInput > 0)
            {
                distance = CalculationsClass.FallingDistance.FallingDistanceCalc(timeInput);
          

                MessageBox.Show("The total distance traveled is\n" + distance + " meters.");
            }
            else
            {
                MessageBox.Show("Please enter a valid amount of time in seconds.");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
