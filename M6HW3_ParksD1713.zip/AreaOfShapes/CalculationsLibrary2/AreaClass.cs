﻿/**
* 08 May 2023
* CSC 153
* Daniel Parks
* Create an overloaded Class to calculate the area of a circle, rectangle and cylinder. Program not required.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculationsLibrary2
{
    public static class AreaClass
    {
        public static double CalculateArea(double radius)
        {
            return Math.PI * radius * radius;
        }

        public static double CalculateArea(double length, double width)
        {
            return length * width;
        }

        public static double CalculateArea(double radius, double height, double set)
        {
            return (2 * Math.PI * radius * (radius + height)*set);
        }
    }
}
