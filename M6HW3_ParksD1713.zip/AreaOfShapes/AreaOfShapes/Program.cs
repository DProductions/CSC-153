﻿/**
* 08 May 2023
* CSC 153
* Daniel Parks
* Create an overloaded Class to calculate the area of a circle, rectangle and cylinder. Program not required.
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalculationsLibrary2;

namespace AreaOfShapes
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("\nEnter 1 for a circle \nEnter 2 for a rectangle \nEnter 3 for a cylinder \nEnter 'q' to quit:\n");
                string input = Console.ReadLine();

                if (input == "q")
                {
                    break;
                }

                if (int.TryParse(input, out int choice))
                {
                    if (choice == 1)
                    {
                        Console.WriteLine("Enter the radius of the circle:");
                        double radius = double.Parse(Console.ReadLine());
                        double area = AreaClass.CalculateArea(radius);
                        Console.WriteLine($"The area of the circle is {area}");
                    }
                    else if (choice == 2)
                    {
                        Console.WriteLine("Enter the length and width of the rectangle, separated by a space:");
                        string[] inputArr = Console.ReadLine().Split();
                        double length = double.Parse(inputArr[0]);
                        double width = double.Parse(inputArr[1]);
                        double area = AreaClass.CalculateArea(length, width);
                        Console.WriteLine($"The area of the rectangle is {area}");
                    }
                    else if (choice == 3)
                    {
                        Console.WriteLine("Enter the radius and height of the cylinder, separated by a space:");
                        string[] inputArr = Console.ReadLine().Split();
                        double radius = double.Parse(inputArr[0]);
                        double height = double.Parse(inputArr[1]);
                        double set = 1;
                        double area = AreaClass.CalculateArea(radius, height, set);
                        Console.WriteLine($"The area of the cylinder is {area}");
                    }
                    else
                    {
                        Console.WriteLine("Invalid choice");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid choice or 'q' to quit.");
                }
            }
        }
    }
}