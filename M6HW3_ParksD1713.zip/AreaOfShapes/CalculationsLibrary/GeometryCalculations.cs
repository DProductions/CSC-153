﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculationsLibrary
{
    public static class AreaClass
    {
    
        public static double CalculateArea(double radius)
        {
            return Math.PI * radius * radius;
        }

        public static double CalculateArea(double length, double width)
        {
            return length * width;
        }

        public static double CalculateArea(double radius, double height)
        {
            return 2 * Math.PI * radius * (radius + height);
        }
    }
}
