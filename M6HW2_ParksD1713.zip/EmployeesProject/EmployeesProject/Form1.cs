﻿/**
* 30 APR 2023
* CSC 153
* Daniel A. Parks
* Load Employee Names from CSV file into ListBox. Display Employee data when clicked in lbl.
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeLibrary;
using System.IO;

namespace EmployeesProject
{
    public partial class frmEmployee : Form

    {
        private List<Employee> employees;
        public frmEmployee()
        {
            InitializeComponent();
            lbxEmployees.SelectedIndexChanged += lbxEmployees_SelectedIndexChanged;
        }
        private void frmEmployee_Load(object sender, EventArgs e)
        { }



        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
                string csvFilePath = @"..\..\..\..\EmployeesProject\EmployeesProject\EmployeesCSV\Employees.csv"; 

                employees = new List<Employee>();

                using (StreamReader reader = new StreamReader(csvFilePath))
                {
                    while (!reader.EndOfStream)
                    {
                        string line = reader.ReadLine();
                        string[] fields = line.Split(',');

                        string name = fields[0];
                        int id = int.Parse(fields[1]);
                        string department = fields[2];
                        string position = fields[3];

                        Employee employee = new Employee(name, id, department, position);
                        employees.Add(employee);
                    }
                }

                lbxEmployees.DataSource = employees;
            }

        private void lbxEmployees_SelectedIndexChanged(object sender, EventArgs e)
        {
            Employee employee = (Employee)lbxEmployees.SelectedItem;
            lblEmployeeData.Text = $"ID: {employee.ID}\nDepartment: {employee.Department}\nPosition: {employee.Position}";
        }
    }
}

