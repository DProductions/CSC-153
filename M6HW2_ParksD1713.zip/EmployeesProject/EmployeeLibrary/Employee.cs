﻿/**
* 30 APR 2023
* CSC 153
* Daniel A. Parks
* Load Employee Names from CSV file into ListBox. Display Employee data when clicked in lbl.
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        public string Name { get; set; }
        public int ID { get; set; }
        public string Department { get; set; }
        public string Position { get; set; }

        public Employee(string name, int id, string department, string position)
        {
            Name = name;
            ID = id;
            Department = department;
            Position = position;
        }

        public override string ToString()
        {
            return Name;
        }
    }
}
