﻿/**
* 25 JAN 2023
* CSC 153
* Daniel Parks - parksd1713
* Paint Job Estimator
*     - Program takes user input for Square Ft. to be painted and price of paint and 
*       outputs paint needed, price of paint required, labor price and total price
*/




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Globalization;
namespace PaintJobEstimator
{
    public partial class Form1 : Form
    {



        public Form1()
        {
            InitializeComponent();



        }

        private void btn_CalculateTotal_Click(object sender, EventArgs e)
        {
            //Create Variables for inputs
            double pricePerGallon;
            double squareFeet;
            //Collect input data
            pricePerGallon = double.Parse(txb_PricePerGallon.Text);
            squareFeet = double.Parse(txb_SquareFeet.Text);

            //number of Gallons of paint required for job
            double numberOfGallons = (squareFeet / 115);
            //number of hours required per job - 115sqft = 8 hours
            double hoursPerLabor = (squareFeet / 14.375);
            //Total Paint price = inputed price * numberOfGallons
            double totalPricePerPaint = pricePerGallon * Math.Ceiling(numberOfGallons);
            //Total Labor = hoursPerLabor * 20.00 per hour
            double laborTotal = ((Math.Ceiling(hoursPerLabor)) * 20.00);
            //totalPrice = Labor + Paint
            double totalPrice = totalPricePerPaint + Math.Ceiling(laborTotal);

            //Display message box with vaiables and format dollar values with ".ToString("C2)" -- (to currency)


            MessageBox.Show(
                (Math.Ceiling(numberOfGallons) + " gallons of paint are required \n")+
                (Math.Ceiling(hoursPerLabor) + " hours of labor required.\n")+
                ("\n") +
                ("Total cost of paint : " +totalPricePerPaint.ToString("C2")+"\n")+
                ("Labor charges :")+ laborTotal.ToString("C2") + ("\n") +
                ("\n")+
                ("Total cost for paint job : " + totalPrice.ToString("C2"))
                );
        }
        // Exit on Click
        private void btn_Exit_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
