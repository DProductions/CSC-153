﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HospitalMethods
{
    public class HospitalChargesCalc
    {
        // Calculate total stay charge
        public static int CalcStayCharges(int Days)
        {
            int stayCharges = Days * 350;
            return stayCharges;
        }
        // Calculate Misc Charges
        public static double CalcMiscCharges(double med, double surgical, double lab, double rehab)
        {
            double miscCharges = med + surgical + lab + rehab;
            return miscCharges;
        }
        // Calculate Total Hospital Stay Charges
        public static double CalcTotalCharges(double stayCharges, double miscCharges)
        {
            double total = stayCharges + miscCharges;
            return total;  
        }
    }
}
