﻿
/**
* Date 25 MAY 2023
* CSC 153
Daniel Parks
* Program description - Calculate the total Hospital Charges
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HospitalMethods;
using System.Globalization;
using System.Text.RegularExpressions;
namespace HospitalCharges
{
    public partial class HospitalChargesForm : Form
    {
        public HospitalChargesForm()
        {
            InitializeComponent();
        }

        public void HospitalChargesForm_Load(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Check each tbx to ensure it is a number, or exit 
            if (Regex.IsMatch(tbxDays.Text, @"^\d+$")){
                if (Regex.IsMatch(tbxMedicationCharges.Text, @"^\d+$")) { 
                    if (Regex.IsMatch(tbxSurgicalCharges.Text, @"^\d+$")) { 
                        if (Regex.IsMatch(tbxLabFees.Text, @"^\d+$")) { 
                            if (Regex.IsMatch(tbxRehabCharges.Text, @"^\d+$")) { 


                                // Set Variable based on user input
                                int totalDays = int.Parse(tbxDays.Text);
                                double medicationCharge = double.Parse(tbxMedicationCharges.Text);
                                double surgicalCharge = double.Parse(tbxSurgicalCharges.Text);
                                double labFees = double.Parse(tbxLabFees.Text);
                                double rehab = double.Parse(tbxRehabCharges.Text);


                                // Call Functions for calculations
                                int stayCharges = HospitalMethods.HospitalChargesCalc.CalcStayCharges(totalDays);
                                double miscCharges = HospitalMethods.HospitalChargesCalc.CalcMiscCharges(medicationCharge, surgicalCharge, labFees, rehab);
                                double total = HospitalMethods.HospitalChargesCalc.CalcTotalCharges(stayCharges, miscCharges);


                                // Display MessageBox with results
                                MessageBox.Show("Total Days in hospital fee is : " + stayCharges.ToString("C", CultureInfo.CurrentCulture) +
                                                "\n\nTotal Misc Charges : " + miscCharges.ToString("C", CultureInfo.CurrentCulture) +
                                                "\n\n Total Charge : " + total.ToString("C", CultureInfo.CurrentCulture));


                             }
                            else{this.Close();}
                        }
                        else{this.Close();}
                    }
                    else{this.Close();}
                }
                else{ this.Close();}
            }
            else{this.Close();}
        }
    }
}
