﻿namespace HospitalCharges
{
    partial class HospitalChargesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.tbxDays = new System.Windows.Forms.TextBox();
            this.tbxMedicationCharges = new System.Windows.Forms.TextBox();
            this.tbxSurgicalCharges = new System.Windows.Forms.TextBox();
            this.tbxLabFees = new System.Windows.Forms.TextBox();
            this.tbxRehabCharges = new System.Windows.Forms.TextBox();
            this.lblDays = new System.Windows.Forms.Label();
            this.lblMedCharge = new System.Windows.Forms.Label();
            this.lblSurgicalCharges = new System.Windows.Forms.Label();
            this.lblLabFees = new System.Windows.Forms.Label();
            this.lblRehabCharges = new System.Windows.Forms.Label();
            this.lblHospitalCharges = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(12, 298);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(106, 30);
            this.btnCalculate.TabIndex = 0;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(153, 298);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(106, 30);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // tbxDays
            // 
            this.tbxDays.Location = new System.Drawing.Point(153, 74);
            this.tbxDays.Name = "tbxDays";
            this.tbxDays.Size = new System.Drawing.Size(94, 20);
            this.tbxDays.TabIndex = 2;
            // 
            // tbxMedicationCharges
            // 
            this.tbxMedicationCharges.Location = new System.Drawing.Point(153, 113);
            this.tbxMedicationCharges.Name = "tbxMedicationCharges";
            this.tbxMedicationCharges.Size = new System.Drawing.Size(94, 20);
            this.tbxMedicationCharges.TabIndex = 3;
            // 
            // tbxSurgicalCharges
            // 
            this.tbxSurgicalCharges.Location = new System.Drawing.Point(153, 155);
            this.tbxSurgicalCharges.Name = "tbxSurgicalCharges";
            this.tbxSurgicalCharges.Size = new System.Drawing.Size(94, 20);
            this.tbxSurgicalCharges.TabIndex = 4;
            // 
            // tbxLabFees
            // 
            this.tbxLabFees.Location = new System.Drawing.Point(153, 197);
            this.tbxLabFees.Name = "tbxLabFees";
            this.tbxLabFees.Size = new System.Drawing.Size(94, 20);
            this.tbxLabFees.TabIndex = 5;
            // 
            // tbxRehabCharges
            // 
            this.tbxRehabCharges.Location = new System.Drawing.Point(153, 241);
            this.tbxRehabCharges.Name = "tbxRehabCharges";
            this.tbxRehabCharges.Size = new System.Drawing.Size(94, 20);
            this.tbxRehabCharges.TabIndex = 6;
            // 
            // lblDays
            // 
            this.lblDays.AutoSize = true;
            this.lblDays.Location = new System.Drawing.Point(14, 81);
            this.lblDays.Name = "lblDays";
            this.lblDays.Size = new System.Drawing.Size(117, 13);
            this.lblDays.TabIndex = 7;
            this.lblDays.Text = "Days Spent in Hospital:";
            // 
            // lblMedCharge
            // 
            this.lblMedCharge.AutoSize = true;
            this.lblMedCharge.Location = new System.Drawing.Point(14, 120);
            this.lblMedCharge.Name = "lblMedCharge";
            this.lblMedCharge.Size = new System.Drawing.Size(125, 13);
            this.lblMedCharge.TabIndex = 8;
            this.lblMedCharge.Text = "Medication Charges:     $";
            // 
            // lblSurgicalCharges
            // 
            this.lblSurgicalCharges.AutoSize = true;
            this.lblSurgicalCharges.Location = new System.Drawing.Point(14, 162);
            this.lblSurgicalCharges.Name = "lblSurgicalCharges";
            this.lblSurgicalCharges.Size = new System.Drawing.Size(123, 13);
            this.lblSurgicalCharges.TabIndex = 9;
            this.lblSurgicalCharges.Text = "Surgical Charges:         $";
            // 
            // lblLabFees
            // 
            this.lblLabFees.AutoSize = true;
            this.lblLabFees.Location = new System.Drawing.Point(14, 204);
            this.lblLabFees.Name = "lblLabFees";
            this.lblLabFees.Size = new System.Drawing.Size(123, 13);
            this.lblLabFees.TabIndex = 10;
            this.lblLabFees.Text = "Lab Fees:                     $";
            // 
            // lblRehabCharges
            // 
            this.lblRehabCharges.AutoSize = true;
            this.lblRehabCharges.Location = new System.Drawing.Point(14, 248);
            this.lblRehabCharges.Name = "lblRehabCharges";
            this.lblRehabCharges.Size = new System.Drawing.Size(122, 13);
            this.lblRehabCharges.TabIndex = 11;
            this.lblRehabCharges.Text = "Phys Rehab Charges:  $";
            // 
            // lblHospitalCharges
            // 
            this.lblHospitalCharges.AutoSize = true;
            this.lblHospitalCharges.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHospitalCharges.Location = new System.Drawing.Point(10, 20);
            this.lblHospitalCharges.Name = "lblHospitalCharges";
            this.lblHospitalCharges.Size = new System.Drawing.Size(250, 20);
            this.lblHospitalCharges.TabIndex = 12;
            this.lblHospitalCharges.Text = "Please enter hospital Charges";
            // 
            // HospitalChargesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(274, 350);
            this.Controls.Add(this.lblHospitalCharges);
            this.Controls.Add(this.lblRehabCharges);
            this.Controls.Add(this.lblLabFees);
            this.Controls.Add(this.lblSurgicalCharges);
            this.Controls.Add(this.lblMedCharge);
            this.Controls.Add(this.lblDays);
            this.Controls.Add(this.tbxRehabCharges);
            this.Controls.Add(this.tbxLabFees);
            this.Controls.Add(this.tbxSurgicalCharges);
            this.Controls.Add(this.tbxMedicationCharges);
            this.Controls.Add(this.tbxDays);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCalculate);
            this.Name = "HospitalChargesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hospital Charges";
            this.Load += new System.EventHandler(this.HospitalChargesForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox tbxDays;
        private System.Windows.Forms.TextBox tbxMedicationCharges;
        private System.Windows.Forms.TextBox tbxSurgicalCharges;
        private System.Windows.Forms.TextBox tbxLabFees;
        private System.Windows.Forms.TextBox tbxRehabCharges;
        private System.Windows.Forms.Label lblDays;
        private System.Windows.Forms.Label lblMedCharge;
        private System.Windows.Forms.Label lblSurgicalCharges;
        private System.Windows.Forms.Label lblLabFees;
        private System.Windows.Forms.Label lblRehabCharges;
        private System.Windows.Forms.Label lblHospitalCharges;
    }
}

