﻿/**
* 15 Feb 2023
* CSC 153
* Daniel Parks
* Change for a Dollar Game
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace M2HW2_Parksd1713
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_PlayGame_Click(object sender, EventArgs e)
        {
            if(tbx_Pennies.Text.Length == 0){
                tbx_Pennies.Text = "0";
            }
            if (tbx_Nickels.Text.Length == 0)
            {
                tbx_Nickels.Text = "0";
            }
            if (tbx_Dimes.Text.Length == 0)
            {
                tbx_Dimes.Text = "0";
            }
            if (tbx_Quarters.Text.Length == 0)
            {
                tbx_Quarters.Text = "0";
            }

            double value =(double.Parse(tbx_Pennies.Text) * 0.01) + (double.Parse(tbx_Dimes.Text) * 0.10) + (double.Parse(tbx_Nickels.Text) * 0.05) + (double.Parse(tbx_Quarters.Text) * 0.25);


            if (value != 1.00){
                MessageBox.Show("You lose! \n\nTotal Change = " + value.ToString("C", CultureInfo.CurrentCulture));
            }
            else
            {
                MessageBox.Show("You Win! \n\nTotal Change = " + value.ToString("C", CultureInfo.CurrentCulture));
            }
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
