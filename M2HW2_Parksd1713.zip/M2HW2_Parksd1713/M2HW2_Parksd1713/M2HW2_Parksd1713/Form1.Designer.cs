﻿
namespace M2HW2_Parksd1713
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbx_Pennies = new System.Windows.Forms.TextBox();
            this.tbx_Nickels = new System.Windows.Forms.TextBox();
            this.tbx_Dimes = new System.Windows.Forms.TextBox();
            this.tbx_Quarters = new System.Windows.Forms.TextBox();
            this.btn_PlayGame = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.lbl_Pennies = new System.Windows.Forms.Label();
            this.lbl_Nickels = new System.Windows.Forms.Label();
            this.lbl_Dimes = new System.Windows.Forms.Label();
            this.lbl_Quarters = new System.Windows.Forms.Label();
            this.lbl_GameLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbx_Pennies
            // 
            this.tbx_Pennies.Location = new System.Drawing.Point(196, 57);
            this.tbx_Pennies.Name = "tbx_Pennies";
            this.tbx_Pennies.Size = new System.Drawing.Size(102, 20);
            this.tbx_Pennies.TabIndex = 0;
            // 
            // tbx_Nickels
            // 
            this.tbx_Nickels.Location = new System.Drawing.Point(196, 95);
            this.tbx_Nickels.Name = "tbx_Nickels";
            this.tbx_Nickels.Size = new System.Drawing.Size(102, 20);
            this.tbx_Nickels.TabIndex = 1;
            // 
            // tbx_Dimes
            // 
            this.tbx_Dimes.Location = new System.Drawing.Point(196, 133);
            this.tbx_Dimes.Name = "tbx_Dimes";
            this.tbx_Dimes.Size = new System.Drawing.Size(102, 20);
            this.tbx_Dimes.TabIndex = 2;
            // 
            // tbx_Quarters
            // 
            this.tbx_Quarters.Location = new System.Drawing.Point(196, 168);
            this.tbx_Quarters.Name = "tbx_Quarters";
            this.tbx_Quarters.Size = new System.Drawing.Size(102, 20);
            this.tbx_Quarters.TabIndex = 3;
            // 
            // btn_PlayGame
            // 
            this.btn_PlayGame.Location = new System.Drawing.Point(48, 216);
            this.btn_PlayGame.Name = "btn_PlayGame";
            this.btn_PlayGame.Size = new System.Drawing.Size(103, 34);
            this.btn_PlayGame.TabIndex = 4;
            this.btn_PlayGame.Text = "Play Game";
            this.btn_PlayGame.UseVisualStyleBackColor = true;
            this.btn_PlayGame.Click += new System.EventHandler(this.btn_PlayGame_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(196, 216);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(103, 34);
            this.btn_Exit.TabIndex = 5;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // lbl_Pennies
            // 
            this.lbl_Pennies.AutoSize = true;
            this.lbl_Pennies.Location = new System.Drawing.Point(45, 60);
            this.lbl_Pennies.Name = "lbl_Pennies";
            this.lbl_Pennies.Size = new System.Drawing.Size(125, 13);
            this.lbl_Pennies.TabIndex = 6;
            this.lbl_Pennies.Text = "Enter Number of Pennies";
            // 
            // lbl_Nickels
            // 
            this.lbl_Nickels.AutoSize = true;
            this.lbl_Nickels.Location = new System.Drawing.Point(45, 98);
            this.lbl_Nickels.Name = "lbl_Nickels";
            this.lbl_Nickels.Size = new System.Drawing.Size(122, 13);
            this.lbl_Nickels.TabIndex = 7;
            this.lbl_Nickels.Text = "Enter Number of Nickels";
            // 
            // lbl_Dimes
            // 
            this.lbl_Dimes.AutoSize = true;
            this.lbl_Dimes.Location = new System.Drawing.Point(45, 136);
            this.lbl_Dimes.Name = "lbl_Dimes";
            this.lbl_Dimes.Size = new System.Drawing.Size(116, 13);
            this.lbl_Dimes.TabIndex = 8;
            this.lbl_Dimes.Text = "Enter Number of Dimes";
            // 
            // lbl_Quarters
            // 
            this.lbl_Quarters.AutoSize = true;
            this.lbl_Quarters.Location = new System.Drawing.Point(45, 171);
            this.lbl_Quarters.Name = "lbl_Quarters";
            this.lbl_Quarters.Size = new System.Drawing.Size(127, 13);
            this.lbl_Quarters.TabIndex = 9;
            this.lbl_Quarters.Text = "Enter Number of Quarters";
            // 
            // lbl_GameLabel
            // 
            this.lbl_GameLabel.AutoSize = true;
            this.lbl_GameLabel.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_GameLabel.Location = new System.Drawing.Point(53, 9);
            this.lbl_GameLabel.Name = "lbl_GameLabel";
            this.lbl_GameLabel.Size = new System.Drawing.Size(245, 24);
            this.lbl_GameLabel.TabIndex = 10;
            this.lbl_GameLabel.Text = "Change for a Dollar Game";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(354, 291);
            this.Controls.Add(this.lbl_GameLabel);
            this.Controls.Add(this.lbl_Quarters);
            this.Controls.Add(this.lbl_Dimes);
            this.Controls.Add(this.lbl_Nickels);
            this.Controls.Add(this.lbl_Pennies);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_PlayGame);
            this.Controls.Add(this.tbx_Quarters);
            this.Controls.Add(this.tbx_Dimes);
            this.Controls.Add(this.tbx_Nickels);
            this.Controls.Add(this.tbx_Pennies);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbx_Pennies;
        private System.Windows.Forms.TextBox tbx_Nickels;
        private System.Windows.Forms.TextBox tbx_Dimes;
        private System.Windows.Forms.TextBox tbx_Quarters;
        private System.Windows.Forms.Button btn_PlayGame;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Label lbl_Pennies;
        private System.Windows.Forms.Label lbl_Nickels;
        private System.Windows.Forms.Label lbl_Dimes;
        private System.Windows.Forms.Label lbl_Quarters;
        private System.Windows.Forms.Label lbl_GameLabel;
    }
}

