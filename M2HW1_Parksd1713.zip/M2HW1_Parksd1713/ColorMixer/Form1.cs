﻿/**
* 12 Feb 2023
* CSC 153
* Daniel Parks
* Color Mixer
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ColorMixer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Mix_Click(object sender, EventArgs e)
        {
            if (rad_Red1.Checked && rad_Red2.Checked)
            {
                this.BackColor = Color.Red;
            }
            else if (rad_Blue1.Checked && rad_Blue2.Checked)
            {
                this.BackColor = Color.Blue;
            }
            else if (rad_Yellow1.Checked && rad_Yellow2.Checked)
            {
                this.BackColor = Color.Yellow;
            }
            else if (rad_Red1.Checked && rad_Blue2.Checked)
            {
                this.BackColor = Color.Purple;
            }
            else if (rad_Red1.Checked && rad_Yellow2.Checked)
            {
                this.BackColor = Color.Orange;
            }
            else if (rad_Blue1.Checked && rad_Red2.Checked)
            {
                this.BackColor = Color.Purple;
            }
            else if (rad_Blue1.Checked && rad_Yellow2.Checked)
            {
                this.BackColor = Color.Green;
            }
            else if (rad_Yellow1.Checked && rad_Red2.Checked)
            {
                this.BackColor = Color.Orange;
            }
            else if (rad_Yellow1.Checked && rad_Blue2.Checked)
            {
                this.BackColor = Color.Green;
            }
            else
            {
                MessageBox.Show("Please make a valid selection", "Error");
            }
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
