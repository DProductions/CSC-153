﻿namespace ColorMixer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rad_Red1 = new System.Windows.Forms.RadioButton();
            this.rad_Blue1 = new System.Windows.Forms.RadioButton();
            this.rad_Yellow1 = new System.Windows.Forms.RadioButton();
            this.rad_Red2 = new System.Windows.Forms.RadioButton();
            this.rad_Blue2 = new System.Windows.Forms.RadioButton();
            this.rad_Yellow2 = new System.Windows.Forms.RadioButton();
            this.btn_Mix = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.gbx_1 = new System.Windows.Forms.GroupBox();
            this.gbx_2 = new System.Windows.Forms.GroupBox();
            this.gbx_1.SuspendLayout();
            this.gbx_2.SuspendLayout();
            this.SuspendLayout();
            // 
            // rad_Red1
            // 
            this.rad_Red1.AutoSize = true;
            this.rad_Red1.Location = new System.Drawing.Point(51, 28);
            this.rad_Red1.Name = "rad_Red1";
            this.rad_Red1.Size = new System.Drawing.Size(45, 17);
            this.rad_Red1.TabIndex = 0;
            this.rad_Red1.TabStop = true;
            this.rad_Red1.Text = "Red";
            this.rad_Red1.UseVisualStyleBackColor = true;
            // 
            // rad_Blue1
            // 
            this.rad_Blue1.AutoSize = true;
            this.rad_Blue1.Location = new System.Drawing.Point(51, 63);
            this.rad_Blue1.Name = "rad_Blue1";
            this.rad_Blue1.Size = new System.Drawing.Size(46, 17);
            this.rad_Blue1.TabIndex = 1;
            this.rad_Blue1.TabStop = true;
            this.rad_Blue1.Text = "Blue";
            this.rad_Blue1.UseVisualStyleBackColor = true;
            // 
            // rad_Yellow1
            // 
            this.rad_Yellow1.AutoSize = true;
            this.rad_Yellow1.Location = new System.Drawing.Point(51, 95);
            this.rad_Yellow1.Name = "rad_Yellow1";
            this.rad_Yellow1.Size = new System.Drawing.Size(56, 17);
            this.rad_Yellow1.TabIndex = 2;
            this.rad_Yellow1.TabStop = true;
            this.rad_Yellow1.Text = "Yellow";
            this.rad_Yellow1.UseVisualStyleBackColor = true;
            // 
            // rad_Red2
            // 
            this.rad_Red2.AutoSize = true;
            this.rad_Red2.Location = new System.Drawing.Point(46, 25);
            this.rad_Red2.Name = "rad_Red2";
            this.rad_Red2.Size = new System.Drawing.Size(45, 17);
            this.rad_Red2.TabIndex = 3;
            this.rad_Red2.TabStop = true;
            this.rad_Red2.Text = "Red";
            this.rad_Red2.UseVisualStyleBackColor = true;
            // 
            // rad_Blue2
            // 
            this.rad_Blue2.AutoSize = true;
            this.rad_Blue2.Location = new System.Drawing.Point(46, 60);
            this.rad_Blue2.Name = "rad_Blue2";
            this.rad_Blue2.Size = new System.Drawing.Size(46, 17);
            this.rad_Blue2.TabIndex = 4;
            this.rad_Blue2.TabStop = true;
            this.rad_Blue2.Text = "Blue";
            this.rad_Blue2.UseVisualStyleBackColor = true;
            // 
            // rad_Yellow2
            // 
            this.rad_Yellow2.AutoSize = true;
            this.rad_Yellow2.Location = new System.Drawing.Point(46, 92);
            this.rad_Yellow2.Name = "rad_Yellow2";
            this.rad_Yellow2.Size = new System.Drawing.Size(58, 17);
            this.rad_Yellow2.TabIndex = 5;
            this.rad_Yellow2.TabStop = true;
            this.rad_Yellow2.Text = "Yelllow";
            this.rad_Yellow2.UseVisualStyleBackColor = true;
            // 
            // btn_Mix
            // 
            this.btn_Mix.Location = new System.Drawing.Point(44, 194);
            this.btn_Mix.Name = "btn_Mix";
            this.btn_Mix.Size = new System.Drawing.Size(88, 28);
            this.btn_Mix.TabIndex = 6;
            this.btn_Mix.Text = "Mix";
            this.btn_Mix.UseVisualStyleBackColor = true;
            this.btn_Mix.Click += new System.EventHandler(this.btn_Mix_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(232, 194);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(88, 28);
            this.btn_Exit.TabIndex = 7;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // gbx_1
            // 
            this.gbx_1.Controls.Add(this.rad_Red1);
            this.gbx_1.Controls.Add(this.rad_Blue1);
            this.gbx_1.Controls.Add(this.rad_Yellow1);
            this.gbx_1.Location = new System.Drawing.Point(12, 26);
            this.gbx_1.Name = "gbx_1";
            this.gbx_1.Size = new System.Drawing.Size(168, 138);
            this.gbx_1.TabIndex = 8;
            this.gbx_1.TabStop = false;
            this.gbx_1.Text = "Select the First Color";
            // 
            // gbx_2
            // 
            this.gbx_2.Controls.Add(this.rad_Red2);
            this.gbx_2.Controls.Add(this.rad_Blue2);
            this.gbx_2.Controls.Add(this.rad_Yellow2);
            this.gbx_2.Location = new System.Drawing.Point(200, 26);
            this.gbx_2.Name = "gbx_2";
            this.gbx_2.Size = new System.Drawing.Size(174, 138);
            this.gbx_2.TabIndex = 9;
            this.gbx_2.TabStop = false;
            this.gbx_2.Text = "Select the Second Color";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(398, 256);
            this.Controls.Add(this.gbx_2);
            this.Controls.Add(this.gbx_1);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Mix);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Color Mixer";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbx_1.ResumeLayout(false);
            this.gbx_1.PerformLayout();
            this.gbx_2.ResumeLayout(false);
            this.gbx_2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton rad_Red1;
        private System.Windows.Forms.RadioButton rad_Blue1;
        private System.Windows.Forms.RadioButton rad_Yellow1;
        private System.Windows.Forms.RadioButton rad_Red2;
        private System.Windows.Forms.RadioButton rad_Blue2;
        private System.Windows.Forms.RadioButton rad_Yellow2;
        private System.Windows.Forms.Button btn_Mix;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.GroupBox gbx_1;
        private System.Windows.Forms.GroupBox gbx_2;
    }
}

