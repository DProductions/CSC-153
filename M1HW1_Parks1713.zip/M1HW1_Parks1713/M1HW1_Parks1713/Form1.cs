﻿/**
* 21 JAN 2023
* CSC 153
* Daniel Parks
* Name Formatter
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW1_Parks1713
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void format1_Click(object sender, EventArgs e)
        {
            lbl_display.Text = titleTxt.Text + " " + fNameTxt.Text + " " + mNameTxt.Text + " " + lNameTxt.Text;
        }
        private void format2_Click_1(object sender, EventArgs e)
        {
            lbl_display.Text = fNameTxt.Text + " " + mNameTxt.Text + " " + lNameTxt.Text;
        }

        private void format3_Click_1(object sender, EventArgs e)
        {
            lbl_display.Text = fNameTxt.Text + " " + lNameTxt.Text;
        }

        private void format4_Click_1(object sender, EventArgs e)
        {
            lbl_display.Text = lNameTxt.Text + ", " + fNameTxt.Text + " " + mNameTxt.Text + ", " + titleTxt.Text;
        }

        private void format5_Click_1(object sender, EventArgs e)
        {
            lbl_display.Text = lNameTxt.Text + ", " + fNameTxt.Text + " " + mNameTxt.Text;
        }

        private void format6_Click_1(object sender, EventArgs e)
        {
            lbl_display.Text = lNameTxt.Text + ", " + fNameTxt.Text;
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            fNameTxt.Clear();
            mNameTxt.Clear();
            lNameTxt.Clear();
            titleTxt.Clear();
            lbl_display.Text = "- - - - - -";
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
