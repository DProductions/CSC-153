﻿namespace M1HW1_Parks1713
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.format1 = new System.Windows.Forms.Button();
            this.format2 = new System.Windows.Forms.Button();
            this.format3 = new System.Windows.Forms.Button();
            this.format4 = new System.Windows.Forms.Button();
            this.format5 = new System.Windows.Forms.Button();
            this.format6 = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.fNameLbl = new System.Windows.Forms.Label();
            this.mNameLbl = new System.Windows.Forms.Label();
            this.lNameLbl = new System.Windows.Forms.Label();
            this.titleLbl = new System.Windows.Forms.Label();
            this.formLbl = new System.Windows.Forms.Label();
            this.fNameTxt = new System.Windows.Forms.TextBox();
            this.mNameTxt = new System.Windows.Forms.TextBox();
            this.lNameTxt = new System.Windows.Forms.TextBox();
            this.titleTxt = new System.Windows.Forms.TextBox();
            this.lbl_display = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // format1
            // 
            this.format1.Location = new System.Drawing.Point(228, 58);
            this.format1.Name = "format1";
            this.format1.Size = new System.Drawing.Size(75, 23);
            this.format1.TabIndex = 0;
            this.format1.Text = "Format 1";
            this.format1.UseVisualStyleBackColor = true;
            this.format1.Click += new System.EventHandler(this.format1_Click);
            // 
            // format2
            // 
            this.format2.Location = new System.Drawing.Point(228, 87);
            this.format2.Name = "format2";
            this.format2.Size = new System.Drawing.Size(75, 23);
            this.format2.TabIndex = 1;
            this.format2.Text = "Format 2";
            this.format2.UseVisualStyleBackColor = true;
            this.format2.Click += new System.EventHandler(this.format2_Click_1);
            // 
            // format3
            // 
            this.format3.Location = new System.Drawing.Point(228, 116);
            this.format3.Name = "format3";
            this.format3.Size = new System.Drawing.Size(75, 23);
            this.format3.TabIndex = 2;
            this.format3.Text = "Format 3";
            this.format3.UseVisualStyleBackColor = true;
            this.format3.Click += new System.EventHandler(this.format3_Click_1);
            // 
            // format4
            // 
            this.format4.Location = new System.Drawing.Point(228, 145);
            this.format4.Name = "format4";
            this.format4.Size = new System.Drawing.Size(75, 23);
            this.format4.TabIndex = 3;
            this.format4.Text = "Format4";
            this.format4.UseVisualStyleBackColor = true;
            this.format4.Click += new System.EventHandler(this.format4_Click_1);
            // 
            // format5
            // 
            this.format5.Location = new System.Drawing.Point(228, 174);
            this.format5.Name = "format5";
            this.format5.Size = new System.Drawing.Size(75, 23);
            this.format5.TabIndex = 4;
            this.format5.Text = "Format 5";
            this.format5.UseVisualStyleBackColor = true;
            this.format5.Click += new System.EventHandler(this.format5_Click_1);
            // 
            // format6
            // 
            this.format6.Location = new System.Drawing.Point(228, 203);
            this.format6.Name = "format6";
            this.format6.Size = new System.Drawing.Size(75, 23);
            this.format6.TabIndex = 5;
            this.format6.Text = "Format 6";
            this.format6.UseVisualStyleBackColor = true;
            this.format6.Click += new System.EventHandler(this.format6_Click_1);
            // 
            // clearBtn
            // 
            this.clearBtn.Location = new System.Drawing.Point(79, 268);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 23);
            this.clearBtn.TabIndex = 6;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(193, 268);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(75, 23);
            this.exitBtn.TabIndex = 7;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // fNameLbl
            // 
            this.fNameLbl.AutoSize = true;
            this.fNameLbl.Location = new System.Drawing.Point(46, 81);
            this.fNameLbl.Name = "fNameLbl";
            this.fNameLbl.Size = new System.Drawing.Size(60, 13);
            this.fNameLbl.TabIndex = 9;
            this.fNameLbl.Text = "First Name:";
            // 
            // mNameLbl
            // 
            this.mNameLbl.AutoSize = true;
            this.mNameLbl.Location = new System.Drawing.Point(35, 120);
            this.mNameLbl.Name = "mNameLbl";
            this.mNameLbl.Size = new System.Drawing.Size(72, 13);
            this.mNameLbl.TabIndex = 10;
            this.mNameLbl.Text = "Middle Name:";
            // 
            // lNameLbl
            // 
            this.lNameLbl.AutoSize = true;
            this.lNameLbl.Location = new System.Drawing.Point(45, 157);
            this.lNameLbl.Name = "lNameLbl";
            this.lNameLbl.Size = new System.Drawing.Size(61, 13);
            this.lNameLbl.TabIndex = 11;
            this.lNameLbl.Text = "Last Name:";
            // 
            // titleLbl
            // 
            this.titleLbl.AutoSize = true;
            this.titleLbl.Location = new System.Drawing.Point(76, 193);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(30, 13);
            this.titleLbl.TabIndex = 12;
            this.titleLbl.Text = "Title:";
            // 
            // formLbl
            // 
            this.formLbl.AutoSize = true;
            this.formLbl.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.formLbl.Location = new System.Drawing.Point(61, 9);
            this.formLbl.Name = "formLbl";
            this.formLbl.Size = new System.Drawing.Size(210, 31);
            this.formLbl.TabIndex = 13;
            this.formLbl.Text = "Name Formatter";
            // 
            // fNameTxt
            // 
            this.fNameTxt.Location = new System.Drawing.Point(112, 74);
            this.fNameTxt.Name = "fNameTxt";
            this.fNameTxt.Size = new System.Drawing.Size(100, 20);
            this.fNameTxt.TabIndex = 15;
            // 
            // mNameTxt
            // 
            this.mNameTxt.Location = new System.Drawing.Point(112, 115);
            this.mNameTxt.Name = "mNameTxt";
            this.mNameTxt.Size = new System.Drawing.Size(100, 20);
            this.mNameTxt.TabIndex = 16;
            // 
            // lNameTxt
            // 
            this.lNameTxt.Location = new System.Drawing.Point(112, 154);
            this.lNameTxt.Name = "lNameTxt";
            this.lNameTxt.Size = new System.Drawing.Size(100, 20);
            this.lNameTxt.TabIndex = 17;
            // 
            // titleTxt
            // 
            this.titleTxt.Location = new System.Drawing.Point(112, 190);
            this.titleTxt.Name = "titleTxt";
            this.titleTxt.Size = new System.Drawing.Size(100, 20);
            this.titleTxt.TabIndex = 18;
            // 
            // lbl_display
            // 
            this.lbl_display.AutoSize = true;
            this.lbl_display.Location = new System.Drawing.Point(78, 231);
            this.lbl_display.Name = "lbl_display";
            this.lbl_display.Size = new System.Drawing.Size(0, 13);
            this.lbl_display.TabIndex = 19;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 320);
            this.Controls.Add(this.lbl_display);
            this.Controls.Add(this.titleTxt);
            this.Controls.Add(this.lNameTxt);
            this.Controls.Add(this.mNameTxt);
            this.Controls.Add(this.fNameTxt);
            this.Controls.Add(this.formLbl);
            this.Controls.Add(this.titleLbl);
            this.Controls.Add(this.lNameLbl);
            this.Controls.Add(this.mNameLbl);
            this.Controls.Add(this.fNameLbl);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.format6);
            this.Controls.Add(this.format5);
            this.Controls.Add(this.format4);
            this.Controls.Add(this.format3);
            this.Controls.Add(this.format2);
            this.Controls.Add(this.format1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button format1;
        private System.Windows.Forms.Button format2;
        private System.Windows.Forms.Button format3;
        private System.Windows.Forms.Button format4;
        private System.Windows.Forms.Button format5;
        private System.Windows.Forms.Button format6;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Label fNameLbl;
        private System.Windows.Forms.Label mNameLbl;
        private System.Windows.Forms.Label lNameLbl;
        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.Label formLbl;
        private System.Windows.Forms.TextBox fNameTxt;
        private System.Windows.Forms.TextBox mNameTxt;
        private System.Windows.Forms.TextBox lNameTxt;
        private System.Windows.Forms.TextBox titleTxt;
        private System.Windows.Forms.Label lbl_display;
    }
}

