﻿
/**
* 23 April 2023
* CSC 153
* Daniel Parks
* Slot Machine App.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using SlotMethodsLibrary;

namespace SlotMachineApplication
{
    public partial class frmSlotMachine : Form
    {
        public frmSlotMachine()
        {
            InitializeComponent();

        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        // Set internal Global variables
        private int totalBetAmount = 0;
        private int totalWinnings = 0;
        private void btnSpin_Click(object sender, EventArgs e)
        {

            int betAmount;


            // test vaule for compatabilityu
            if (!int.TryParse(tbxInserted.Text, out betAmount) || betAmount <= 0)
            {
                MessageBox.Show("Please enter a valid positive bet amount.");
                return;
            }

            // initialize random numbers and save to variables (1-10)
            Random rand = new Random();
            int num1 = rand.Next(1, 11);
            int num2 = rand.Next(1, 11);
            int num3 = rand.Next(1, 11);


            // call function from library for image file path
            string pic1 = MachineMethods.GetImagePath(num1);
            string pic2 = MachineMethods.GetImagePath(num2);
            string pic3 = MachineMethods.GetImagePath(num3);


            // display in picture box
            picBox1.ImageLocation = pic1;
            picBox2.ImageLocation = pic2;
            picBox3.ImageLocation = pic3;


            // set initial winnings to the negative bet amount
            int winnings = -betAmount;

            // triple winnings if all three numbers match
            if (num1 == num2 && num2 == num3)
            {
                winnings += betAmount * 3; 
            }
            // double winnings if two numbers match
            else if (num1 == num2 || num1 == num3 || num2 == num3)
            {
                winnings += betAmount * 2;
            }


            // update total winnings and total bet amount
            totalWinnings += winnings; 
            totalBetAmount += betAmount; 

            // Update label to display current winnings/losses and total bet amount
            lblWinnings.Text = string.Format(
                "Current winnings/losses: {0:C}\nTotal bet amount: {1:C}",
                totalWinnings, totalBetAmount
            );
        }
    }
}


