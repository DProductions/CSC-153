﻿
/**
* 23 April 2023
* CSC 153
* Daniel Parks
* Slot Machine App.
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SlotMethodsLibrary
{
    public class MachineMethods
    {
        public static string GetImagePath(int num)
        {
            string imagePath;
            switch (num)
            {
                case 1:
                    imagePath = @"..\..\..\SlotMethodsLibrary\Symbols\Apple.bmp";
                    break;
                case 2:
                    imagePath = @"..\..\..\SlotMethodsLibrary\Symbols\Banana.bmp";
                    break;
                case 3:
                    imagePath = @"..\..\..\SlotMethodsLibrary\Symbols\Cherries.bmp";
                    break;
                case 4:
                    imagePath = @"..\..\..\SlotMethodsLibrary\Symbols\Grapes.bmp";
                    break;
                case 5:
                    imagePath = @"..\..\..\SlotMethodsLibrary\Symbols\Lemon.bmp";
                    break;
                case 6:
                    imagePath = @"..\..\..\SlotMethodsLibrary\Symbols\Lime.bmp";
                    break;
                case 7:
                    imagePath = @"..\..\..\SlotMethodsLibrary\Symbols\Orange.bmp";
                    break;
                case 8:
                    imagePath = @"..\..\..\SlotMethodsLibrary\Symbols\Pear.bmp";
                    break;
                case 9:
                    imagePath = @"..\..\..\SlotMethodsLibrary\Symbols\Strawberry.bmp";
                    break;
                case 10:
                    imagePath = @"..\..\..\SlotMethodsLibrary\Symbols\Watermelon.bmp";
                    break;

                default:
                    imagePath = ""; // Return empty string if number is not 1, 2, or 3
                    break;
            }
            return imagePath;
        }
    }
}
