﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("");
            Console.WriteLine("Name : Daniel A. Parks");
            Console.WriteLine("");
            Console.WriteLine("Would like to learn : I would like to learn about C# and add it to my 'tool-box'.");
            Console.WriteLine("");
            Console.WriteLine("Priviously taken : Web Development, JAVA, PYTHON");
            Console.WriteLine("");
            Console.WriteLine("What was not learned : All the topics in the list were covered. I would like to learn how each topic is run in C#.");
            Console.ReadLine();
        }
    }
}
