﻿namespace Random_Number_File_Reader
{
    partial class frmNumbersInFile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbxReadNumbers = new System.Windows.Forms.ListBox();
            this.lblTotalNumbers = new System.Windows.Forms.Label();
            this.lblNumberRead = new System.Windows.Forms.Label();
            this.btnSelectFile = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbxReadNumbers
            // 
            this.lbxReadNumbers.FormattingEnabled = true;
            this.lbxReadNumbers.Location = new System.Drawing.Point(24, 18);
            this.lbxReadNumbers.Name = "lbxReadNumbers";
            this.lbxReadNumbers.Size = new System.Drawing.Size(182, 251);
            this.lbxReadNumbers.TabIndex = 0;
            // 
            // lblTotalNumbers
            // 
            this.lblTotalNumbers.AutoSize = true;
            this.lblTotalNumbers.Location = new System.Drawing.Point(38, 292);
            this.lblTotalNumbers.Name = "lblTotalNumbers";
            this.lblTotalNumbers.Size = new System.Drawing.Size(0, 13);
            this.lblTotalNumbers.TabIndex = 1;
            // 
            // lblNumberRead
            // 
            this.lblNumberRead.AutoSize = true;
            this.lblNumberRead.Location = new System.Drawing.Point(38, 332);
            this.lblNumberRead.Name = "lblNumberRead";
            this.lblNumberRead.Size = new System.Drawing.Size(0, 13);
            this.lblNumberRead.TabIndex = 2;
            // 
            // btnSelectFile
            // 
            this.btnSelectFile.Location = new System.Drawing.Point(227, 42);
            this.btnSelectFile.Name = "btnSelectFile";
            this.btnSelectFile.Size = new System.Drawing.Size(100, 28);
            this.btnSelectFile.TabIndex = 3;
            this.btnSelectFile.Text = "Select File";
            this.btnSelectFile.UseVisualStyleBackColor = true;
            this.btnSelectFile.Click += new System.EventHandler(this.btnSelectFile_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(232, 152);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(95, 28);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmNumbersInFile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 378);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSelectFile);
            this.Controls.Add(this.lblNumberRead);
            this.Controls.Add(this.lblTotalNumbers);
            this.Controls.Add(this.lbxReadNumbers);
            this.Name = "frmNumbersInFile";
            this.Text = "Numbers in File";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbxReadNumbers;
        private System.Windows.Forms.Label lblTotalNumbers;
        private System.Windows.Forms.Label lblNumberRead;
        private System.Windows.Forms.Button btnSelectFile;
        private System.Windows.Forms.Button btnClose;
    }
}

