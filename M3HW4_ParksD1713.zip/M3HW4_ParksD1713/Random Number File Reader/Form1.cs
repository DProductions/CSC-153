﻿/**
* Date: 12 MAR 2023
* CSC 153
* Daniel Parks
* Program description : Read previously generated Random numbers from file. Display number in listbox, add total of numbers and count lines in file
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Random_Number_File_Reader
{
    public partial class frmNumbersInFile : Form
    {
        public frmNumbersInFile()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSelectFile_Click(object sender, EventArgs e)
        {
            // OpenFileDialog = select file to read
            OpenFileDialog fd = new OpenFileDialog();
            fd.ShowDialog();
            StreamReader rd = new StreamReader(fd.FileName);
            string lineFromTheFile = "";


            //create loop 
            while ((lineFromTheFile = rd.ReadLine()) != null)
            {
                // extract text from file to listbox
                lbxReadNumbers.Items.Add(lineFromTheFile);
            }
            // variable for addition of random numbers
            int numbersSum = 0;
            // loop for each value (i) in list box
            for (int i = 0; i < lbxReadNumbers.Items.Count; i++)
            {
                // Parse to int and add each item in listbox
                numbersSum = numbersSum + int.Parse(lbxReadNumbers.Items[i].ToString());
            }
            // Display The total of the numbers
            lblTotalNumbers.Text = "The total of the numbers : " + numbersSum;
            // Display The number of random numbers read from the file
            lblNumberRead.Text = "The number of random numbers read from the file : " + lbxReadNumbers.Items.Count;
        }
    }
}
