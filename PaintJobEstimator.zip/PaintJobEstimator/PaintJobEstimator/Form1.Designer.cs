﻿namespace PaintJobEstimator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txb_SquareFeet = new System.Windows.Forms.TextBox();
            this.txb_PricePerGallon = new System.Windows.Forms.TextBox();
            this.lbl_SquareFeet = new System.Windows.Forms.Label();
            this.lbl_PricePerGallon = new System.Windows.Forms.Label();
            this.btn_CalculateTotal = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txb_SquareFeet
            // 
            this.txb_SquareFeet.Location = new System.Drawing.Point(167, 79);
            this.txb_SquareFeet.Name = "txb_SquareFeet";
            this.txb_SquareFeet.Size = new System.Drawing.Size(100, 20);
            this.txb_SquareFeet.TabIndex = 0;
            // 
            // txb_PricePerGallon
            // 
            this.txb_PricePerGallon.Location = new System.Drawing.Point(167, 125);
            this.txb_PricePerGallon.Name = "txb_PricePerGallon";
            this.txb_PricePerGallon.Size = new System.Drawing.Size(100, 20);
            this.txb_PricePerGallon.TabIndex = 1;
            // 
            // lbl_SquareFeet
            // 
            this.lbl_SquareFeet.AutoSize = true;
            this.lbl_SquareFeet.Location = new System.Drawing.Point(21, 86);
            this.lbl_SquareFeet.Name = "lbl_SquareFeet";
            this.lbl_SquareFeet.Size = new System.Drawing.Size(136, 13);
            this.lbl_SquareFeet.TabIndex = 2;
            this.lbl_SquareFeet.Text = "Square feet to be painted : ";
            // 
            // lbl_PricePerGallon
            // 
            this.lbl_PricePerGallon.AutoSize = true;
            this.lbl_PricePerGallon.Location = new System.Drawing.Point(21, 128);
            this.lbl_PricePerGallon.Name = "lbl_PricePerGallon";
            this.lbl_PricePerGallon.Size = new System.Drawing.Size(127, 13);
            this.lbl_PricePerGallon.TabIndex = 3;
            this.lbl_PricePerGallon.Text = "Price per gallon of paint : ";
            // 
            // btn_CalculateTotal
            // 
            this.btn_CalculateTotal.Location = new System.Drawing.Point(18, 189);
            this.btn_CalculateTotal.Name = "btn_CalculateTotal";
            this.btn_CalculateTotal.Size = new System.Drawing.Size(97, 23);
            this.btn_CalculateTotal.TabIndex = 4;
            this.btn_CalculateTotal.Text = "Calculate Total";
            this.btn_CalculateTotal.UseVisualStyleBackColor = true;
            this.btn_CalculateTotal.Click += new System.EventHandler(this.btn_CalculateTotal_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(170, 189);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(97, 23);
            this.btn_Exit.TabIndex = 5;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click_1);
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Header.Location = new System.Drawing.Point(22, 19);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(245, 31);
            this.lbl_Header.TabIndex = 6;
            this.lbl_Header.Text = "Paint Job Estimator";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 252);
            this.Controls.Add(this.lbl_Header);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_CalculateTotal);
            this.Controls.Add(this.lbl_PricePerGallon);
            this.Controls.Add(this.lbl_SquareFeet);
            this.Controls.Add(this.txb_PricePerGallon);
            this.Controls.Add(this.txb_SquareFeet);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txb_SquareFeet;
        private System.Windows.Forms.TextBox txb_PricePerGallon;
        private System.Windows.Forms.Label lbl_SquareFeet;
        private System.Windows.Forms.Label lbl_PricePerGallon;
        private System.Windows.Forms.Button btn_CalculateTotal;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Label lbl_Header;
    }
}

