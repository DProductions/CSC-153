﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Globalization;
namespace PaintJobEstimator
{
    public partial class Form1 : Form
    {



        public Form1()
        {
            InitializeComponent();



        }

        private void btn_CalculateTotal_Click(object sender, EventArgs e)
        {
            //Create Variables for inputs
            double pricePerGallon;
            double squareFeet;
            //Collect input data
            pricePerGallon = double.Parse(txb_PricePerGallon.Text);
            squareFeet = double.Parse(txb_SquareFeet.Text);

            //number of Gallons of paint required for job
            double numberOfGallons = (squareFeet / 115);
            //number of hours required per job - 115sqft = 8 hours
            double hoursPerLabor = (squareFeet / 115)*8;
            //Total Paint price = inputed price * numberOfGallons
            double totalPricePerPaint = pricePerGallon * numberOfGallons;
            //Total Labor = hoursPerLabor * 20.00 per hour
            double laborTotal = ((hoursPerLabor) * 20.00);
            //totalPrice = Labor + Paint
            double totalPrice = totalPricePerPaint + laborTotal;

            //Display message box with vaiables
            MessageBox.Show((numberOfGallons + " number of gallons of paint are required \n")+
                (hoursPerLabor + " hours of labor required.\n")+
                ("\n") +
                ("Total Cost of Paint : $" +totalPricePerPaint+"\n")+
                ("$")+ laborTotal + ("  in labor charges.\n")+
                ("\n")+
                ("Total Cost for paint job : $" + totalPrice));
        }
        // Exit on Click
        private void btn_Exit_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
