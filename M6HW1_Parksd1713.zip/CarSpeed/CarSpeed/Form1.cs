﻿/**
* 29 APR 2023
* CSC 153
* Daniel Parks
* Create a Car. Add 5 MPH of speed or brake by 5 MPH
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using CarLibrary;



namespace CarSpeed
{
    public partial class frmCarSpeed : Form
    {
        private Car car;
        public frmCarSpeed()
        {
            InitializeComponent();
            car = null;
        }

        private void brnCreateCar_Click(object sender, EventArgs e)
        {
            int year = int.Parse(tbxYear.Text);
            string model = tbxModel.Text;
            car = new Car(year, model);
            lblCarInfo.Text = $"Year: {car.Year}, Model: {car.Model}, Speed: {car.Speed} mph";
        }

        private void btnAccelerate_Click(object sender, EventArgs e)
        {
            if (car != null)
            {
                car.Accelerate();
                lblCarInfo.Text = $"Year: {car.Year}, Model: {car.Model}, Speed: {car.Speed} mph";
            }
        }

        private void btnBrake_Click(object sender, EventArgs e)
        {
            if (car != null)
            {
                car.Brake();
                lblCarInfo.Text = $"Year: {car.Year}, Model: {car.Model}, Speed: {car.Speed} mph";
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
