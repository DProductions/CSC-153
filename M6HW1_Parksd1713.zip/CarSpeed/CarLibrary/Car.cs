﻿/**
* 29 APR 2023
* CSC 153
* Daniel Parks
* Create a Car. Add 5 MPH of speed or brake by 5 MPH
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;



namespace CarLibrary
{
    public class Car
    {
        private int year;

        private string model;

        private int speed;



        public Car(int year, string model)

        {

            this.year = year;

            this.model = model;

            speed = 0;

        }



        public int Year

        {

            get { return year; }

            set { year = value; }

        }



        public string Model

        {

            get { return model; }

            set { model = value; }

        }



        public int Speed

        {

            get { return speed; }

            set { speed = value; }

        }



        public void Accelerate()

        {

            speed += 5;

        }



        public void Brake()

        {

            speed = Math.Max(0, speed - 5);

        }
    }
}
