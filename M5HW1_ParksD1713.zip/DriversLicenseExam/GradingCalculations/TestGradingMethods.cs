﻿
/**
* 08 APR 2023
* CSC 153
* Daniel Parks
* DriversLicenseExam - take a user determined file location and grade it compaired to a pre-determined
*                      answer key. Display percentage on test, number correct and all incorrect questions.
*/






/ Set Namespace
namespace GradingCalculations
{
    // Set Class Name
    public class TestGradingMethods
    {
        // Method to identify user txt file path
        public static string GetUserFilePath()
        {
            Console.WriteLine("Enter the file path of your test file with only 20 lines, each with only a single letter answer (A-D):");
            string filePath = Console.ReadLine();

            if (!File.Exists(filePath))
            {
                return null;
            }

            // return file path
            return filePath;
        }

        // Method to Read user file
        public static string[] ReadUserAnswers(string filePath)
        {
            return File.ReadAllLines(filePath);
        }

        // Method to determine questions answered correctly in user file compared to hardcoded anserKey
        public static int GetNumCorrectAnswers(string[] answerKey, string[] userAnswers)
        {
            int numCorrectAnswers = 0;

            for (int i = 0; i < answerKey.Length; i++)
            {
                if (answerKey[i] == userAnswers[i])
                {
                    numCorrectAnswers++;
                }
            }

            // return number of correclty answered questions 
            return numCorrectAnswers;
        }

        // Method to calculate percentage
        public static double GetGradePercentage(int numCorrectAnswers, int numTotalAnswers)
        {
            // return percentage of correctly answered questions
            return (double)numCorrectAnswers / numTotalAnswers * 100;
        }
        
        // Method to identify the number of questions answered incorrectly
        public static int[] GetIncorrectQuestionNumbers(string[] answerKey, string[] userAnswers)
        {
            int[] incorrectQuestionNumbers = new int[userAnswers.Length];
            int numIncorrectAnswers = 0;

            for (int i = 0; i < answerKey.Length; i++)
            {
                if (answerKey[i] != userAnswers[i])
                {
                    incorrectQuestionNumbers[numIncorrectAnswers] = i + 1;
                    numIncorrectAnswers++;
                }
            }

            Array.Resize(ref incorrectQuestionNumbers, numIncorrectAnswers);

            // return number of questions answered incorrectly
            return incorrectQuestionNumbers;
        }
    }
}