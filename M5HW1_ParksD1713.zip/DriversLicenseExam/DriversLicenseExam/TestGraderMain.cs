﻿
/**
* 08 APR 2023
* CSC 153
* Daniel Parks
* DriversLicenseExam - take a user determined file location and grade it compaired to a pre-determined
*                      answer key. Display percentage on test, number correct and all incorrect questions.
*/

using System;
using System.IO;
using GradingCalculations;

// set class name 
class TestGrader
{
    // set Main program method
    static void Main(string[] args)
    {
        // set list of correct answeres
        string[] answerKey = {"b", "D", "A", "A", "C", "A", "B", "A", "C", "D",
                          "B", "C", "D", "A", "D", "C", "C", "B", "D", "A"};

        // identify txt file path
        string filePath = TestGradingMethods.GetUserFilePath();
        if (filePath == null)
        {
            Console.WriteLine("File does not exist.");
            return;
        }

        // test file, calculate numb correct, numb incorrect, test percentage and incorrect answers
        string[] userAnswers = TestGradingMethods.ReadUserAnswers(filePath);
        int numCorrectAnswers = TestGradingMethods.GetNumCorrectAnswers(answerKey, userAnswers);
        double gradePercentage = TestGradingMethods.GetGradePercentage(numCorrectAnswers, answerKey.Length);
        int[] incorrectQuestionNumbers = TestGradingMethods.GetIncorrectQuestionNumbers(answerKey, userAnswers);


        // Display results
        Console.WriteLine("\n\n              Your grade is {0:F2}%.", gradePercentage);
        Console.WriteLine("      You answered " + numCorrectAnswers + " question(s) correctly.");

        if (incorrectQuestionNumbers.Length > 0)
        {
            Console.WriteLine("The following questions were answered incorrectly:");
            foreach (int questionNumber in incorrectQuestionNumbers)
            {
                Console.WriteLine("                -   Question {0}", questionNumber);
            }
        }
        else
        {
            Console.WriteLine("Congratulations! You answered all questions correctly.");
        }
        Console.WriteLine("\n");
    }




}