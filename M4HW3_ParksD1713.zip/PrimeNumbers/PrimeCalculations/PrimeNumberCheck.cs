﻿/**
* 01 April 2023
* CSC 153
* Daniel Parks
* Program description - Class Library - Check variable "userInput" to determin if it is a Prime number or not.
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeCalculations
{
    public class PrimeNumberCheck
    {
        public static bool IsPrime(int userInput)
        {
            if (userInput < 2)
            {
                return false;
            }
            else if (userInput == 2)
            {
                return true;
            }
            else if (userInput % 2 == 0)
            {
                return false;
            }
            else
            {
                int maxDivisor = (int)Math.Sqrt(userInput);
                for (int i = 3; i <= maxDivisor; i += 2)
                {
                    if (userInput % i == 0)
                    {
                        return false;
                    }
                }
                return true;
            }
        }
    }
}
