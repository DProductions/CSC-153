﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;




namespace RandomNumberFileWriter
{
    public partial class frmSaveRandNum : Form
    {
        public frmSaveRandNum()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Create and Format Save window
            String file;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            int randNumbers;
            saveFileDialog1.Filter = "txt files (*.txt)|*.txt";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;


            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                file = saveFileDialog1.FileName;


                // Identify invalid responses = ! True, response of a positive value
                if (!(int.TryParse(tbxNumberOfRand.Text, out randNumbers)))
                    MessageBox.Show("Enter a positive value.");
                
                // Identify valid responses.
                else
                {
                    // set random number to write to file per iteration per input.
                    Random random = new Random();
                    StreamWriter writer = new StreamWriter(file);
                    for (int i = 0; i < randNumbers; i++)
                    {
                        writer.WriteLine(random.Next(1, 100));
                    }
                    writer.Close();
                }
            }

            }

            private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
