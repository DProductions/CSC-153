﻿/**
* Date: 05 MAR 2023
* CSC 153
* Daniel Parks
* Pennies For Pay
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PenniesForPay
{
    public partial class frmPenniesForPay : Form
    {
        public frmPenniesForPay()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        { 
            // Identify variables
            int count;
            double daysPaidFor = double.Parse(txbDaysPaid.Text);
            int addFirstDay;
            double paycheck = 1;

            // Loop through 'daysPaidFor', 'count' times
            for (count = 1; count <= daysPaidFor; count++)
            {
                // calcualte payceck values repeatedly added and doubled.
                paycheck *=2;
                


            }

            // Display resurts in Form Label
                // subtract initial value of 1 from paycheck
                // multipy by .01 for number of cents
                // format to currency.
            lblPaycheck.Text = ((paycheck-1)*.01).ToString("C");


        }
    }
}
