﻿/**
* 01 FEB 2023
* CSC 153
* Daniel A. Parks
* Program Takes user input of property value. Calculates the ammount of property taxes to be applied, then 
*       displays the property value, taxes to be applied and combined property value (taxes + property value).
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PropertyTax
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // On Calculate click - open message box with calculations.
        private void btn_Calculate_Click(object sender, EventArgs e)
        {
            // Identify property value variable and convert input to double.
            double propertyValue;
            propertyValue = double.Parse(tbx_PropertyValue.Text);


            

            // Display message box with values calculated and convert to string.
            MessageBox.Show("$" + (tbx_PropertyValue.Text) + " is the value of the property.\n\n" +
                (((propertyValue/100)*0.64)).ToString("C2")+ " will be property taxes.\n\n"+
                (((propertyValue / 100) * 0.64)+ propertyValue).ToString("C2") + " equals property tax and property value."); 
        }
        // Exit on click.
        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
