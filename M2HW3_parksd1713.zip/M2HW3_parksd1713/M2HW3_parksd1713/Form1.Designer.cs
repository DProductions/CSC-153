﻿namespace M2HW3_parksd1713
{
    partial class form_TimeCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_TimeCalculator = new System.Windows.Forms.Label();
            this.lbl_Instructions = new System.Windows.Forms.Label();
            this.btn_Quit = new System.Windows.Forms.Button();
            this.btn_Calculate = new System.Windows.Forms.Button();
            this.tbx_NumSec = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_TimeCalculator
            // 
            this.lbl_TimeCalculator.AutoSize = true;
            this.lbl_TimeCalculator.Location = new System.Drawing.Point(51, 21);
            this.lbl_TimeCalculator.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbl_TimeCalculator.Name = "lbl_TimeCalculator";
            this.lbl_TimeCalculator.Size = new System.Drawing.Size(207, 31);
            this.lbl_TimeCalculator.TabIndex = 0;
            this.lbl_TimeCalculator.Text = "Time Calculator";
            this.lbl_TimeCalculator.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_Instructions
            // 
            this.lbl_Instructions.AutoSize = true;
            this.lbl_Instructions.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Instructions.Location = new System.Drawing.Point(12, 62);
            this.lbl_Instructions.Name = "lbl_Instructions";
            this.lbl_Instructions.Size = new System.Drawing.Size(281, 23);
            this.lbl_Instructions.TabIndex = 1;
            this.lbl_Instructions.Text = "Please enter number of seconds :";
            // 
            // btn_Quit
            // 
            this.btn_Quit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Quit.Location = new System.Drawing.Point(155, 166);
            this.btn_Quit.Name = "btn_Quit";
            this.btn_Quit.Size = new System.Drawing.Size(123, 31);
            this.btn_Quit.TabIndex = 3;
            this.btn_Quit.Text = "Quit";
            this.btn_Quit.UseVisualStyleBackColor = true;
            this.btn_Quit.Click += new System.EventHandler(this.btn_Quit_Click);
            // 
            // btn_Calculate
            // 
            this.btn_Calculate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Calculate.Location = new System.Drawing.Point(26, 166);
            this.btn_Calculate.Name = "btn_Calculate";
            this.btn_Calculate.Size = new System.Drawing.Size(123, 31);
            this.btn_Calculate.TabIndex = 4;
            this.btn_Calculate.Text = "Calculate";
            this.btn_Calculate.UseVisualStyleBackColor = true;
            this.btn_Calculate.Click += new System.EventHandler(this.btn_Calculate_Click);
            // 
            // tbx_NumSec
            // 
            this.tbx_NumSec.AcceptsReturn = true;
            this.tbx_NumSec.AcceptsTab = true;
            this.tbx_NumSec.BackColor = System.Drawing.SystemColors.Menu;
            this.tbx_NumSec.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbx_NumSec.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbx_NumSec.Location = new System.Drawing.Point(81, 104);
            this.tbx_NumSec.Name = "tbx_NumSec";
            this.tbx_NumSec.Size = new System.Drawing.Size(142, 32);
            this.tbx_NumSec.TabIndex = 5;
            // 
            // form_TimeCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(315, 219);
            this.Controls.Add(this.tbx_NumSec);
            this.Controls.Add(this.btn_Calculate);
            this.Controls.Add(this.btn_Quit);
            this.Controls.Add(this.lbl_Instructions);
            this.Controls.Add(this.lbl_TimeCalculator);
            this.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.Name = "form_TimeCalculator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Time Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_TimeCalculator;
        private System.Windows.Forms.Label lbl_Instructions;
        private System.Windows.Forms.Button btn_Quit;
        private System.Windows.Forms.Button btn_Calculate;
        private System.Windows.Forms.TextBox tbx_NumSec;
    }
}

