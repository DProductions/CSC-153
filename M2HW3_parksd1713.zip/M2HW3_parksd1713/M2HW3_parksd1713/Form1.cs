﻿/**
* 25 FEB 2023
* CSC 153
* Daniel Parks
* Time Calculator
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW3_parksd1713
{
    public partial class form_TimeCalculator : Form
    {
        public form_TimeCalculator()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_Quit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Calculate_Click(object sender, EventArgs e)
        {
            int numSec;
            numSec = int.Parse(tbx_NumSec.Text);
            int days = 0;
            int hours = 0;
            int minutes = 0;


            // Divide integers only. 

          
            if (numSec <= 0)
            {
                MessageBox.Show("Please enter a number of\nseconds, about '0'");
            }
            else {


                // Days 
                if (numSec >= 86400)
                {
                    days = numSec / 86400;
                    numSec = numSec - (days * 86400);
                }

                // Hours
                if (numSec >= 3600)
                {
                    hours = numSec / 3600;
                    numSec = numSec - (hours * 3600);
                }

                // Minutes
                if (numSec >= 60)
                {
                    minutes = numSec / 60;
                    numSec = numSec - (minutes * 60);
                }
                MessageBox.Show(days + "  Days\n" + hours + "  Hours\n" + minutes + "  Minutes\n" + numSec + "  Seconds");
            }
            

        }
    }
}
